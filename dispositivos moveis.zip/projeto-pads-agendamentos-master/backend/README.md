# BACK-END do projeto

## Para rodar o projeto

Primeiro vá em `src/database/` tem um script, para rodar no MySQL, só precisa roda uma vez. E aproveite e leia o README.md da pasta, tem mais informações.

```
cd backend/
npm i
npm start
```

## Pasta src/

Nesta pasta estão os controllers e models da aplicação