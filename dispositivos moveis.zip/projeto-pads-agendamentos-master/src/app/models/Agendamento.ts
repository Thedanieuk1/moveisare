export class Agendamento {
	public especialidade: number;
	public medico: number;
	public paciente: number;
	public data: Date;
	public hora: string;
}
